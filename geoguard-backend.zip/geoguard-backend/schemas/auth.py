from pydantic import BaseModel
from models.user import UserRole


class UserCreate(BaseModel):
    username: str
    password: str
    role: UserRole
    station: str | None = None


class UserOut(BaseModel):
    id: str
    username: str
    role: UserRole
    station: str | None

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: UserRole
    user_id: str


class LoginRequest(BaseModel):
    username: str
    password: str
