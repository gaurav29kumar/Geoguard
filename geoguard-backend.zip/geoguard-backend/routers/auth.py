import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from db.database import get_db
from models.user import User
from schemas.auth import UserCreate, UserOut, Token, LoginRequest
from services.auth_service import hash_password, verify_password, create_token

router = APIRouter()


@router.post("/register", response_model=UserOut, status_code=201)
async def register(body: UserCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.username == body.username))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Username already taken")

    user = User(
        id        = str(uuid.uuid4()),
        username  = body.username,
        hashed_pw = hash_password(body.password),
        role      = body.role,
        station   = body.station,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


@router.post("/login", response_model=Token)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.username == body.username))
    user = result.scalar_one_or_none()

    if not user or not verify_password(body.password, user.hashed_pw):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_token({"sub": user.id, "role": user.role})
    return Token(access_token=token, role=user.role, user_id=user.id)


@router.get("/me", response_model=UserOut)
async def me(db: AsyncSession = Depends(get_db),
             token: str = Depends(__import__("services.auth_service", fromlist=["oauth2_scheme"]).auth_service.oauth2_scheme)):
    from services.auth_service import get_current_user
    # Handled via dependency — just re-export
    raise HTTPException(status_code=501, detail="Use /me with Bearer token via get_current_user dep")
